package pharma;
import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
//import java.sql.PreparedStatements;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;  
import javax.servlet.http.Cookie;  



public class add extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out= response.getWriter();
        String name=request.getParameter("name");
        String price=request.getParameter("price");
        String qun=request.getParameter("qun");
        String brand=request.getParameter("brand");

       try  {
            Class.forName("com.mysql.jdbc.Driver");
            
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root","");
            PreparedStatement ss = (PreparedStatement) con.prepareStatement("insert into product (name,price,qun,brand) values (?,?,?,?);");
            int i;
            ss.setString(1,name);
            ss.setString(2,price);
            ss.setString(3,qun);
            ss.setString(4,brand);
            i = ss.executeUpdate();
            
           
            
            if(i!=0){
              out.print(" <script type=\"text/javascript\">");
              out.print("alert('Product Add Successfully');");
              out.print("location='add.html';");
              out.print("</script>");
            }
            else
            {
              out.print(" <script type=\"text/javascript\">");
              out.print("location='add.html';");
              out.print("alert('You Can Not Add Same Product');");
              out.print("</script>");
            }
               
        }catch(Exception e){out.println(e);} 
    }
}   