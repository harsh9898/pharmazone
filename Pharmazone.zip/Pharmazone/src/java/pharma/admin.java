/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pharma;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.*; 
import javax.servlet.RequestDispatcher;
import javax.swing.JOptionPane;

public class admin extends HttpServlet {

    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        try 
        {
            String email=request.getParameter("email");
            String password=request.getParameter("password");
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","");
           
           Statement s=con.createStatement();  
         
           ResultSet rs=s.executeQuery("select * from admin where email = '"+email+"' and password = '"+password+"';");
           
          if(rs.next())
          {
              
               out.print(" <script type=\"text/javascript\">");
              out.print("location='adminpanel.html';");
              out.print("alert('signin successfull');");
              out.print("</script>");
                    Cookie ck=new Cookie("email","okk");//creating cookie object  
                    response.addCookie(ck);
                   
          }
          else
          {
              out.print(" <script type=\"text/javascript\">");
              out.print("location='login.html';");
              out.print("alert('Enter Correct  Passsword');");
              out.print("</script>");
          }
        }catch(Exception e)
        {
            out.print(e);
        }
    }

   
    
}
