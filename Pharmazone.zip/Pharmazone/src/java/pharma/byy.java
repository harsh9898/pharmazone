
package pharma;
import pharma.loginin;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.RequestDispatcher;

/**
 *
 * @author Nirmal
 */
public class byy extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            Cookie ck[]=request.getCookies(); 
            if(ck[0].getValue()!=null){
                ck[0].setMaxAge(0); 
              response.addCookie(ck[0]);
              out.print(" <script type=\"text/javascript\">");
              out.println("hello");
              out.print("alert('Log Out Successfull');");
              out.print("location='home.html';");
              out.print("</script>");
              RequestDispatcher rd = request.getRequestDispatcher(""+request.getContextPath()+"index.html");
              rd.forward(request, response);
            //  response.sendRedirect("index.html");
            }
            /* TODO output your page here. You may use following sample code. */
            
        }catch(Exception e)
        {
            out.println(e);
        }
    }


}
