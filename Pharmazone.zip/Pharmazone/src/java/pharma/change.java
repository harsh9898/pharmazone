/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pharma;

import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.*; 
import javax.servlet.RequestDispatcher;
import javax.swing.JOptionPane;

public class change extends HttpServlet {

    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        try 
        {
            String email=request.getParameter("email");
            String password=request.getParameter("password");
            String cpassword=request.getParameter("cpassword");
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","");
            PreparedStatement ss = (PreparedStatement) con.prepareStatement("update  info set password=? where email = '"+email+"' and password = '"+password+"';");
            ss.setString(1,cpassword);
            int i=ss.executeUpdate();
             if(i!=0){
              out.print(" <script type=\"text/javascript\">");
              out.print("alert('password updated successfully');");
              out.print("location='buy.html';");
              out.print("</script>");
            }
            else{
              out.print(" <script type=\"text/javascript\">");
              out.print("location='buy.html';");
              out.print("alert('pls check email and password details are correct');");
              out.print("</script>");
            }
           
        }catch(Exception e)
        {
            out.print(e);
        }
    }

   
    
}
