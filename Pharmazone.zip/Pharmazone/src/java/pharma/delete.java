package pharma;
import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
//import java.sql.PreparedStatements;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;  
import javax.servlet.http.Cookie;  



public class delete extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out= response.getWriter();
        String name=request.getParameter("name");
        String price=request.getParameter("price");
        String qun=request.getParameter("qun");
        String brand=request.getParameter("brand");

       try  {
            Class.forName("com.mysql.jdbc.Driver");
            
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root","");
            PreparedStatement ss = (PreparedStatement) con.prepareStatement("delete from product where name=?");
            int i;
            ss.setString(1,name);
            i = ss.executeUpdate();
            
           
            
            if(i!=0){
              out.print(" <script type=\"text/javascript\">");
              out.print("alert('Product Delete Successfully');");
              out.print("location='delete.html';");
              out.print("</script>");
            }
            else{
              out.print(" <script type=\"text/javascript\">");
              out.print("location='delete.html';");
              out.print("alert('Product Not Available');");
              out.print("</script>");
            }
               
        }catch(Exception e){out.println(e);} 
    }
}   