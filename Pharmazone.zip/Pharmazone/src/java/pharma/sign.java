package pharma;
import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
//import java.sql.PreparedStatements;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;  
import javax.servlet.http.Cookie;  



public class sign extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out= response.getWriter();
        String fname=request.getParameter("fname");
        String lname=request.getParameter("lname");
        String email=request.getParameter("email");
        String password=request.getParameter("password");
        String phone_no=request.getParameter("phone_no");
        String gender=request.getParameter("gender");
       try  {
            Class.forName("com.mysql.jdbc.Driver");
            
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root","");
            PreparedStatement ss = (PreparedStatement) con.prepareStatement("insert into info (fname,lname,email,password,phone_no,gender) values (?,?,?,?,?,?);");
            int i;
            ss.setString(1,fname);
            ss.setString(2,lname);
            ss.setString(3,email);
            ss.setString(4,password);
            ss.setString(5,phone_no);
            ss.setString(6, gender);
            i = ss.executeUpdate();
            
           
            
            if(i!=0){
              out.print(" <script type=\"text/javascript\">");
              out.print("alert('signup successfull');");
              out.print("location='signup.html';");
              out.print("</script>");
            }
            else{
              out.print(" <script type=\"text/javascript\">");
              out.print("location='signup.html';");
              out.print("alert('signup fail');");
              out.print("</script>");
            }
               
        }catch(Exception e){out.println(e);} 
    }
}   