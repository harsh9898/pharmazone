/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pharma;

import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.*; 
import javax.servlet.RequestDispatcher;
import javax.swing.JOptionPane;

public class update extends HttpServlet {

    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        try 
        {
           String name=request.getParameter("name");
        String price=request.getParameter("price");
        String qun=request.getParameter("qun");
        String brand=request.getParameter("brand");
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","");
            PreparedStatement ss = (PreparedStatement) con.prepareStatement("update product set price=?,qun=?  where name = '"+name+"' and brand = '"+brand+"';");
            ss.setString(1,price);
            ss.setString(2,qun);
            int i=ss.executeUpdate();
             if(i!=0){
              out.print(" <script type=\"text/javascript\">");
              out.print("alert('Product Updated successfully');");
              out.print("location='update.html';");
              out.print("</script>");
            }
            else{
              out.print(" <script type=\"text/javascript\">");
              out.print("location='update.html';");
              out.print("alert('Pls Check Product Name And Brand details are correct');");
              out.print("</script>");
            }
           
        }catch(Exception e)
        {
            out.print(e);
        }
    }

   
    
}
